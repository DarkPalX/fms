<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Carbon\Carbon;
use Auth;
use DB;

use App\IssuanceRequest;
use App\Vehicles;
use App\Dispatch;

class VehicleController extends Controller
{
    public function index(){

        $vehicles = Vehicles::where('isECS',0)->orderBy('name', 'asc')->paginate(10); 

        return view('vehicle.index',compact('vehicles'));
    }

    public function store(Request $req)
    {
        Vehicles::create([
            'name' => $req->name,
            'plateno' => $req->plateno,
            'vehicle_code' => $req->ccode,
            'type' => $req->type,
            'dept' => $req->dept,
            'isECS' => 0
        ]);

        return redirect(route('vehicle.lists'))->with('successMsg', 'Vehicle has been added.');
    }

    // public function vehicleInfo($id){

    //     $qry = IssuanceRequest::where('vehicle_id',$id);
    //     $details = Vehicles::find($id);

    //     $issuances = $qry->where('status','ISSUED')->orderBy('id','desc')->paginate(10);
    //     $total_actual_qty = $qry->where('status','ISSUED')->sum('actual_qty');
        
    //     return view('vehicle.summary',compact('details','issuances','total_actual_qty'));
    // }
    public function vehicleInfo($id){

        $qry = IssuanceRequest::where('vehicle_id',$id);
        $details = Vehicles::find($id);

        if($details->type == 'Heavy Equipment'){
            return $this->heavy_equipment_profile($id);
        }

        $issuances = $qry->where('status','ISSUED')->orderBy('processed_at','desc')->paginate(10);
        $total_actual_qty = $qry->where('status','ISSUED')->sum('actual_qty');

        $data = IssuanceRequest::where('vehicle_id',$id)
            ->whereStatus('ISSUED')
            ->where('odo','>',0)
            ->where('actual_qty','>',0)
            // ->orderBy('created_at', 'ASC')
            ->orderBy('processed_at', 'ASC')
            ->get();
        $previous_odo = 0;
        $previous_fuel_qty = 0;
        $distance_traveled = 0;
        $fuel_economy = 0;
        $fuel_consumption = 0;
        
        
        $cntr = 0;
        $oth['total_distance']=0;
        $oth['total_fuel_issued']=0;
        $raw = '';
        $avg = 0;
        $ss = '';

        $my_hack_data = [];

        foreach($data as $d){
            if($d->odo <= 0.01){
                $d->odo = 0.01;
            }
            $cntr++;
            $is_tag = '';

            // distance traveled = current odo - previous odo
            // fuel econ         = distance traveled / fuel actual quantity
            // fuel consumption  = fuel act qty / distance traveled * consumption_divisor
            // total distance
            // total fuel issued
            // 

            if($cntr > 1){
                $distance_traveled = $d->odo - $previous_odo;
                if($distance_traveled == 0){
                    $distance_traveled = 0.01;
                }
                if($previous_odo == $d->odo){
                    $fuel_economy = $fuel_economy;
                    $fuel_consumption = $fuel_consumption;
                    $oth['total_distance']+=$distance_traveled;
                    $oth['total_fuel_issued']+=$d->actual_qty;
                }
                else{
                    $fuel_economy = $distance_traveled / $d->actual_qty;
                    $fuel_consumption = ($d->actual_qty / $distance_traveled) * env('CONSUMPTION_DIVISOR');
                    $diff = $avg - $fuel_economy;                    
                    
                    $oth['total_distance']+=$distance_traveled;
                    $oth['total_fuel_issued']+=$d->actual_qty;

                    if($oth['total_fuel_issued'] > 0){
                        $avg = $oth['total_distance'] / ($oth['total_fuel_issued']);
                    }
                    if($diff >= env('STANDARD_DIFF')  || $diff <= (env('STANDARD_DIFF')*-1)){
                        $is_tag='<i class="fa fa-exclamation-triangle" style="color:red"></i>';
                    }
                }
            }
            else{
                $oth['total_fuel_issued']+=$d->actual_qty;
            }
               

            array_push($my_hack_data,'<tr>
                    <td><a target="_blank" href="'.route('view.issuance',$d->id).'">'.$d->uniq_code.'</a></td>
                    <td>'.$d->rq.'</td>     
                    <td>'.date('Y-m-d H:i A',strtotime($d->processed_at)).'</td>           
                    <td>'.number_format($previous_odo,2).'</td>
                    <td>'.number_format($d->odo,2).'</td>
                    <td>'.number_format($distance_traveled,2).'</td>                    
                    <td>'.number_format($previous_fuel_qty,2).'</td>
                    <td>'.number_format($d->actual_qty,2).'</td>
                    <td>'.number_format($fuel_economy,2).' '.$is_tag.'</td>
                    <td>'.number_format($fuel_consumption,4).'</td>
                    <td>'.$d->type.'</td>
                    <td>'.$d->location.'</td>               
                </tr>');

            
            
            $previous_odo = $d->odo;
            $previous_fuel_qty = $d->actual_qty;
        }
    
        $hack_collection = collect(array_reverse($my_hack_data));
        $hack_collection = $hack_collection->chunk(10);

        if(request()->has('page')) {
            foreach($hack_collection[$_GET['page'] - 1] as $data1) {
                $raw .= $data1;
            }
        } else {
            foreach($hack_collection[0] as $data1) {
                $raw .= $data1;
            }
        }

        if($cntr>1 && $oth['total_distance'] > 0){
            $oth['fuel_economy'] = number_format(($oth['total_distance'] / $oth['total_fuel_issued'] ),2);
            $oth['fuel_consumption'] = number_format((($oth['total_fuel_issued']/$oth['total_distance'] ) * env('CONSUMPTION_DIVISOR')),4);            
            $oth['last_odo'] = number_format(($d->odo ?? 0),2);
        }else{
            $oth['fuel_economy'] = 0;
            $oth['fuel_consumption'] = 0;            
            $oth['last_odo'] = number_format(($d->odo ?? 0),2);
        }
        
        return view('vehicle.summary',compact('details','issuances','total_actual_qty','raw','oth','data'));
    }

    public function heavy_equipment_profile($id){

        $details = Vehicles::find($id);
        if($details->isECS == 0){
            $dispatch_id = $details->crossref_vid;
        }
        else{
            $dispatch_id = $details->id;   
        }

        //return $this->get_total_hours_used($previous_odo,$d->processed_at,$dispatch_id);

        $qry = IssuanceRequest::where('vehicle_id',$id);
        //dd($qry->where('status','ISSUED')->orderBy('id','desc')->get());
        
       
        $issuances = $qry->where('status','ISSUED')->orderBy('id','desc')->paginate(10);
        $total_actual_qty = $qry->where('status','ISSUED')->sum('actual_qty');

        $data = IssuanceRequest::where('vehicle_id',$id)->whereStatus('ISSUED')->where('odo','>',0)->where('actual_qty','>',0)->get();
        $starting_hr = 0;
        $final_hr = 0;
        $working_hr = 0;
        $previous_date = '';
        $previous_fuel_qty = 0;
        $distance_traveled = 0;
        $fuel_economy = 0;
        $fuel_consumption = 0;
        
        
        $cntr = 0;
        $oth['total_distance']=0;
        $oth['total_fuel_issued']=0;
        $oth['total_working_hour']=0;
        $raw = '';
        $avg = 0;
        $ss = '';
        $arrayTransaction = Array(); 
        $arrayConsuData = Array();
        

        foreach($data as $d){

            if($d->odo <= 0.01){
                $d->odo = 0.01;
            }
            $cntr++;
            $is_tag = '';

            if($cntr > 1){                
                //$distance_traveled = strtotime($d->processed_at) - strtotime($previous_odo);
                $hrs_used = $this->get_total_hours_used($previous_date,$d->processed_at,$dispatch_id);
                $starting_hr = $previous_hr;
                $final_hr += $hrs_used; 
            }
            else{               

                $previous_dispatched = Dispatch::where('unitId',$dispatch_id)->where('dateEnd','<',$d->processed_at)->orderBy('dateEnd','DESC')->first();
                if($previous_dispatched){
                    $starting_hr = $this->get_total_hours_used('2000-01-01 00:01 AM',$previous_dispatched->dateEnd,$dispatch_id);

                    $final_hr = $this->get_total_hours_used($previous_dispatched->dateEnd,$d->processed_at,$dispatch_id) + $starting_hr;
                }else{
                    $final_hr = $this->get_total_hours_used('2000-01-01 00:01 AM',$d->processed_at,$dispatch_id);
                }

                
            }
            
            $working_hr = $final_hr - $starting_hr;
            if($working_hr > 0){
                $fuel_consumption = $d->actual_qty / $working_hr;
            }

            $oth['total_fuel_issued']+=$d->actual_qty;
            $oth['total_working_hour']+=$working_hr;
                    
            array_push($arrayTransaction,array(date('m-d-Y',strtotime($d->processed_at))));
            array_push($arrayConsuData,array(round($fuel_consumption,4)));

            $raw .= '<tr>
                        <td><a target="_blank" href="'.route('view.issuance',$d->id).'">'.$d->uniq_code.'</a></td>
                        <td>'.$d->rq.'</td>        
                        <td>'.date('Y-m-d H:i A',strtotime($d->processed_at)).'</td>         
                        <td>'.number_format($starting_hr,2).'</td>
                        <td>'.number_format($final_hr,2).'</td>
                        <td>'.number_format($working_hr,2).'</td>                    
                        <td>'.number_format($d->actual_qty,2).'</td>
                        <td>'.number_format($fuel_consumption,2).'</td>                 
                        <td>'.$d->type.'</td>
                        <td>'.$d->location.'</td>               
                    </tr>';
            
            
            $previous_hr = $final_hr;
            $previous_date = $d->processed_at;
            $previous_fuel_qty = $d->actual_qty;
        }
    

        if($cntr>1 && $oth['total_distance'] > 0){
            $oth['fuel_economy'] = number_format(($oth['total_distance'] / $oth['total_fuel_issued'] ),2);
            $oth['fuel_consumption'] = number_format((($oth['total_fuel_issued']/$oth['total_distance'] ) * env('CONSUMPTION_DIVISOR')),4);            
            $oth['last_odo'] = number_format(($d->odo ?? 0),2);
        }else{
            $oth['fuel_economy'] = 0;
            $oth['fuel_consumption'] = 0;            
            $oth['last_odo'] = number_format(($d->odo ?? 0),2);
        }
        
        return view('vehicle.summary-heavy_equipment',compact('details','issuances','total_actual_qty','raw','oth','data','arrayTransaction','arrayConsuData'));
    }

    public function get_total_hours_used($start,$end,$vehicle)
    {
        $dispatches = Dispatch::where('unitId',$vehicle)->where('dateStart','>=',$start)->where('dateStart','<=',$end)->get();
        $total = 0;
        foreach($dispatches as $d){
            $total += round((strtotime($d->dateEnd) - strtotime($d->dateStart))/3600, 1);
        }
        return $dispatches->count();
    }

    public function update(Request $req)
    {
        Vehicles::find($req->vid)->update([
            'name' => $req->name,
            'plateno' => $req->plateno,
            'vehicle_code' => $req->ccode,
            'type' => $req->type,
            'dept' => $req->dept
        ]);

        return back()->with('successMsg','Vehicle details has been updated.');
    }

    public function delete(Request $req)
    {
        Vehicles::find($req->vid)->delete();

        return back()->with('successMsg', 'Vehicle has been deleted.');
    }

}
